// .lighthouserc.js
const puppeteer = require('puppeteer');

module.exports = {
  ci: {
    collect: {
      puppeteerScript: './puppeteerScript.js',
      chromePath: puppeteer.executablePath(),
      //url: "http://127.0.0.1:8080",
      numberOfRuns: 1,
      settings: {
        locale: 'ko', // 한국어 설정
        preset: 'desktop',
      },
      puppeteerLaunchOptions: {
        slowMo: 20,
        headless: false,
        disableStorageReset: true
      },
    },
    upload: {
      target: 'filesystem',
      outputDir: './lighthouse-results',
    },
  },
};