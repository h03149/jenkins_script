//puppeteerScript.js
module.exports = async (browser, context) => {
    const page = await browser.newPage(); // page 객체 생성
    console.log("객체 생성");

    // 기본 탐색 시간 설정
    await page.setDefaultNavigationTimeout(90000);
    console.log("탐색 시간 설정");

    // 로그인 페이지로 이동
    await page.goto('http://127.0.0.1:8080/login?from=%2F');
    console.log("로그인 페이지 이동");

    // 사용자 이름과 비밀번호 입력
    await page.type('#j_username.jenkins-input', 'admin');
    console.log("ID 입력");
    await page.type('#j_password.jenkins-input', 'new1234!');
    console.log("PW 입력");

    // 로그인 버튼 클릭
    await page.click('.jenkins-button.jenkins-button--primary');
    console.log("로그인 버튼 선택");
};